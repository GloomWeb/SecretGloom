// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once

#include <collection.h>
#include <ppltasks.h>

// C++\WinRT Headers
#include "Windows.Foundation.Diagnostics.h"
